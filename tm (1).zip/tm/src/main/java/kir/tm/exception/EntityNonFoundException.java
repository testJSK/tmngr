package kir.tm.exception;

public class EntityNonFoundException extends Exception{
    public EntityNonFoundException(String message) {
        super(message);
    }
}
