package kir.tm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmApplicationTests {

	@Test
	void contextLoads() {
	}

}
